
// group.js - Group Chat Routes
const express = require("express");
const { createGroup, addMember } = require("../controllers/groupController");

const router = express.Router();

router.post("/create", createGroup);
router.post("/addMember", addMember);

module.exports = router;
