
// chatController.js - Chat Logic
const Chat = require("../models/Chat");

exports.sendMessage = async (req, res) => {
    const { sender, receiver, message } = req.body;
    try {
        const chat = new Chat({ sender, receiver, message });
        await chat.save();
        res.json(chat);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};

exports.getMessages = async (req, res) => {
    const { chatId } = req.params;
    try {
        const messages = await Chat.find({ chatId });
        res.json(messages);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};
