
// groupController.js - Group Management
const Group = require("../models/Group");

exports.createGroup = async (req, res) => {
    const { groupName, members } = req.body;
    try {
        const group = new Group({ groupName, members });
        await group.save();
        res.json(group);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};

exports.addMember = async (req, res) => {
    const { groupId, memberId } = req.body;
    try {
        const group = await Group.findById(groupId);
        if (!group) return res.status(404).json({ msg: "Group not found" });

        group.members.push(memberId);
        await group.save();
        res.json(group);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};
